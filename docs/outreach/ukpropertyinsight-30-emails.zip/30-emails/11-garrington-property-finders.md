# 11. Garrington Property Finders (buying agent)

**To:** info@garrington.co.uk

**Subject:** The distance a council published, before the viewing

---

Hello,

Your own guide to finding a home near the right school is the reason I am writing.

I built UKPropertyInsight, a due-diligence tool for the questions a buyer asks before they offer: sold prices, flood risk, crime, energy rating, running costs, and the one most sites skip, how far each school actually admitted from in the last round. Councils publish that figure after offer day, usually inside a PDF. It is here for 3,627 schools across 88 councils, checkable against any postcode.

https://ukpropertyinsight.co.uk/school/102156/fortismere-school

If it is useful, send me an address you are working on and I will email the report back the same day, free. There is also a Chrome extension that puts the same figures on a Rightmove, Zoopla or OnTheMarket listing while you browse.

Michael
ukpropertyinsight.co.uk

If you would rather not hear from me, reply with "no thanks" and I will not write again.

---

Address read from garrington.co.uk/contact on 30 September 2026. Sent: ____  Replied: ____
